from flask_cors import  cross_origin
import pafy
from selenium import webdriver
from bs4 import BeautifulSoup
import mysql.connector as connection
from flask import Flask, render_template, request
import time
from selenium.webdriver import Chrome
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pytube import extract, YouTube


mydb = connection.connect(host="localhost", user="root", passwd="Kevali108$")

app = Flask(__name__)

@app.route('/',methods=['GET'])  # route to display the home page
@cross_origin()
def homePage():
    return render_template("index.html")

@app.route('/listVideos',methods=['POST','GET']) # route to show the review comments in a web UI
@cross_origin()
def getVideoList():
    if request.method == 'POST':
        try:
            search_url = request.form['content'].replace(" ","")
            print(search_url)

            latest_video_url = '{}/videos?view=0&sort=p&flow=grid'.format(search_url)
            print(latest_video_url)
            driver = webdriver.Chrome()
            driver.get(latest_video_url)#latest video page of channel
            content = driver.page_source.encode('utf-8').strip()
            soup = BeautifulSoup(content, 'lxml')

            video_id = extract.video_id(latest_video_url)
            print(video_id)
            titles = soup.findAll('a',id='video-title')
            video_views = soup.findAll('span',class_='style-scope ytd-grid-video-renderer')

            video_urls = soup.findAll('a',id='video-title')

            cursor = mydb.cursor()
            i = 0
            j = 0
            k = 1

            q2 = """SELECT video_id FROM youtube.yt_videoList where video_id = %s"""
            cursor = mydb.cursor()
            cursor.execute(q2, (video_id,))
            existing  = cursor.fetchall()

            if (existing == []):
                for title in titles[:20]:
                            q1 = "INSERT INTO youtube.yt_videoList (video_id, video_title, video_link, video_views, video_posted_on) VALUES (%s,%s,%s,%s,%s)"
                            cursor.execute(q1,(video_id, title.text, "https://www.youtube.com" + video_urls[i].get('href'), video_views[j].text, video_views[k].text))
                            mydb.commit()
                            i+=1
                            j+=2
                            k+=2
            else:
                print("ALreay Fetched")

            q3= """SELECT * FROM youtube.yt_videoList where video_id = %s"""
            cursor = mydb.cursor()
            cursor.execute(q3,(video_id,))
            videos = cursor.fetchall()
            driver.close()
            return render_template('results.html', videos=videos[0:(len(videos)-1)])

        except Exception as e:
             print('The Exception message is: ', e)
             return 'something is wrong'

    else:
        return render_template('index.html')

@app.route('/get_url',methods=['GET'])  # route to display the home page
@cross_origin()
def getURL():
    return render_template("videoDetails.html")

@app.route('/VideoDetails',methods=['POST','GET']) # route to show the review comments in a web UI
@cross_origin()
def getVideoDetails():
    if request.method == 'POST':
        try:
            #get selected url to load video details and fetch all comments
            search_url = request.form['selected_item']
            print(search_url)

            comments = []
            commenters = []

            #get video_id
            video_id = extract.video_id(search_url)
            print(video_id)

            my_video = YouTube(search_url)

            video1 = pafy.new(search_url)

            #get thumbnail image url
            image = my_video.thumbnail_url
            print(image)

            #to download video
           # my_video = my_video.streams.get_highest_resolution()
            #my_video.download()

            #get number of likes
            likes = video1.likes

            with Chrome() as driver:
                wait = WebDriverWait(driver, 10)
                driver.get(search_url)


                for item in range(5):  # by increasing the highest range you can get more content
                    wait.until(EC.visibility_of_element_located((By.TAG_NAME, "body"))).send_keys(Keys.END)
                    time.sleep(3)

                for comment in wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "#comment #content-text"))):
                    comments.append(comment.text)
                    #print(comment.text)

                for commenter in wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "#comment #author-text"))):
                    #print(commenter.text)
                    commenters.append(commenter.text)

                #get total number of comments
                no_comments = len(comments)
                driver.close()

                q2 = """SELECT video_id FROM youtube.yt_commentList where video_id = %s"""
                cursor = mydb.cursor()
                cursor.execute(q2, (video_id,))
                existing = cursor.fetchall()
                i = 0
                if (existing == []):
                    for comment in comments[:20]:
                        q1 = "INSERT INTO youtube.yt_commentList (video_id, video_url, video_thumbnail, video_likes, no_of_comments,video_comment,video_commenter) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                        cursor.execute(q1, (video_id, search_url,image,likes, no_comments,comment, commenters[i]))
                        mydb.commit()
                        i += 1

                else:
                    print("something went wrong")

                q3 = """SELECT * FROM youtube.yt_commentList where video_id = %s"""
                cursor = mydb.cursor()
                cursor.execute(q3, (video_id,))
                all_commments = cursor.fetchall()

                return render_template('comments.html', all_commments= all_commments[0:(len(all_commments) - 1)])


        except Exception as e:
             print('The Exception message is: ', e)
             return 'something is wrong'

    else:
        return render_template('index.html')

@app.route('/downloadVideo',methods=['POST','GET']) # route to show the review comments in a web UI
@cross_origin()
def getVideo():
    if request.method == 'POST':
        try:
            #get selected url to load video details and fetch all comments
            search_url = request.form['download_video']
            print(search_url)

            my_video = YouTube(search_url)
            my_video = my_video.streams.get_highest_resolution()
            my_video.download()

            return render_template('dowloadVideo.html')
        except Exception as e:
             print('The Exception message is: ', e)
             return 'something is wrong'

    else:
        return render_template('index.html')


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000, debug=True)

